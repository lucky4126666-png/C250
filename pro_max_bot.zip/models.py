from sqlalchemy import Column, Integer, String, Text
from db import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String)
    password = Column(String)

class AutoPost(Base):
    __tablename__ = "autopost"
    id = Column(Integer, primary_key=True)
    chat_id = Column(String)
    text = Column(Text)