from fastapi import APIRouter, HTTPException
import jwt, datetime

router = APIRouter()
SECRET = "secret"

@router.post("/login")
async def login(data: dict):
    if data.get("username") == "admin" and data.get("password") == "123456":
        token = jwt.encode(
            {"exp": datetime.datetime.utcnow() + datetime.timedelta(hours=12)},
            SECRET,
            algorithm="HS256"
        )
        return {"token": token}
    raise HTTPException(401, "Unauthorized")