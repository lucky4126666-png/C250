from fastapi import APIRouter
from db import SessionLocal
from models import AutoPost
from sqlalchemy import select

router = APIRouter()

@router.get("/")
async def list_posts():
    async with SessionLocal() as db:
        posts = (await db.execute(select(AutoPost))).scalars().all()
    return posts

@router.post("/")
async def create_post(data: dict):
    async with SessionLocal() as db:
        post = AutoPost(**data)
        db.add(post)
        await db.commit()
    return {"ok": True}